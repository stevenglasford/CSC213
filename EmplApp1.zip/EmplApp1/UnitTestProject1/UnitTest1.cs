﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmplApp1;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            
        }
    }
}
